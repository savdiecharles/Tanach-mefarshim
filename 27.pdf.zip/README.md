# Tanach & Mefarshim — iPhone prototype

This is a clickable interface prototype for the app structure discussed:
- Tanach navigation controls
- Major commentator categories
- An all-works catalogue
- Search interface
- A sample verse/commentary view

IMPORTANT: This prototype does NOT yet contain AlHaTorah's full texts or a live source integration. The sample list and sample verse are illustrative only. The next development stage is to verify what AlHaTorah exposes and permits for reuse, then connect real text, metadata, search, and passage-level commentary links.

## iPhone-only publishing
1. Unzip the project on your iPhone.
2. Create a repository on GitHub.
3. Upload `index.html`, `manifest.json`, and `service-worker.js` from this folder to the repository root.
4. Enable GitHub Pages for the repository's `main` branch and root folder.
5. Open the published HTTPS URL in Safari, tap Share, then Add to Home Screen.

This is a prototype, not an official AlHaTorah app. Do not imply affiliation or redistribute source texts unless their terms permit it.
